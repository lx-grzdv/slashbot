#!/usr/bin/env python3
"""
Скрипт для получения информации о чатах и добавления группового чата
"""
import asyncio
import json
from telegram import Bot
from config import BOT_TOKEN

async def get_bot_chats():
    """Получает информацию о боте и инструкции по добавлению чата"""
    
    bot = Bot(token=BOT_TOKEN)
    
    print("=" * 60)
    print("🤖 Информация о боте")
    print("=" * 60)
    
    try:
        bot_info = await bot.get_me()
        print(f"✅ Бот подключен: @{bot_info.username}")
        print(f"   ID: {bot_info.id}")
        print(f"   Имя: {bot_info.first_name}")
    except Exception as e:
        print(f"❌ Ошибка подключения: {e}")
        return
    
    print()
    print("=" * 60)
    print("📋 Текущие чаты в базе:")
    print("=" * 60)
    
    # Читаем текущие чаты
    try:
        with open('bot_users.json', 'r', encoding='utf-8') as f:
            users_data = json.load(f)
            chat_ids = users_data.get('chat_ids', [])
            
        if chat_ids:
            for chat_id in chat_ids:
                try:
                    chat = await bot.get_chat(chat_id)
                    chat_type = chat.type
                    chat_title = chat.title if chat.title else f"{chat.first_name or 'Личный чат'}"
                    print(f"  • ID: {chat_id} | Тип: {chat_type} | Название: {chat_title}")
                except Exception as e:
                    print(f"  • ID: {chat_id} | ⚠️ Не удалось получить информацию: {e}")
        else:
            print("  ⚠️ База чатов пуста")
    except Exception as e:
        print(f"❌ Ошибка чтения базы: {e}")
    
    print()
    print("=" * 60)
    print("💡 Как добавить групповой чат:")
    print("=" * 60)
    print("1. Откройте групповой чат 'S:P9 works'")
    print("2. Отправьте команду /start в группу")
    print("3. Бот автоматически добавит чат в базу")
    print()
    print("⚠️ ВАЖНО:")
    print("   • Если бот не отвечает, выключите Privacy Mode в @BotFather")
    print("   • Или сделайте бота администратором группы")
    print()
    print("🔧 Команда для @BotFather:")
    print("   /mybots → выберите бота → Bot Settings → Group Privacy → Disable")
    print("=" * 60)

async def add_chat_manually(chat_id: int):
    """Добавляет чат вручную в базу"""
    try:
        with open('bot_users.json', 'r', encoding='utf-8') as f:
            users_data = json.load(f)
            chat_ids = users_data.get('chat_ids', [])
    except:
        chat_ids = []
    
    if chat_id not in chat_ids:
        chat_ids.append(chat_id)
        
        with open('bot_users.json', 'w', encoding='utf-8') as f:
            json.dump({'chat_ids': chat_ids}, f, ensure_ascii=False, indent=2)
        
        print(f"✅ Чат {chat_id} добавлен в базу!")
    else:
        print(f"ℹ️ Чат {chat_id} уже есть в базе")

if __name__ == "__main__":
    print()
    print("Выберите действие:")
    print("1 - Показать информацию о чатах")
    print("2 - Добавить чат вручную (если знаете Chat ID)")
    print()
    
    choice = input("Введите номер (1 или 2): ").strip()
    
    if choice == "1":
        asyncio.run(get_bot_chats())
    elif choice == "2":
        chat_id_str = input("Введите Chat ID группы: ").strip()
        try:
            chat_id = int(chat_id_str)
            asyncio.run(add_chat_manually(chat_id))
        except ValueError:
            print("❌ Неверный формат Chat ID")
    else:
        # По умолчанию просто показываем информацию
        asyncio.run(get_bot_chats())
