import asyncio
from telegram import Bot
from config import BOT_TOKEN

async def send_message():
    """Отправляет сообщение в чат"""
    bot = Bot(token=BOT_TOKEN)
    chat_id = -1002413642408  # ID чата (супергруппы)
    message = "@checha_G а ты когда уже отчаливаешь в братьям сербам?"
    
    try:
        await bot.send_message(chat_id=chat_id, text=message)
        print(f"✅ Сообщение успешно отправлено в чат {chat_id}")
    except Exception as e:
        print(f"❌ Ошибка при отправке сообщения: {e}")

if __name__ == "__main__":
    asyncio.run(send_message())
