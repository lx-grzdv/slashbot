#!/usr/bin/env python3
import asyncio
import json
from telegram import Bot
from config import BOT_TOKEN

USERS_FILE = "bot_users.json"

async def send_broadcast_message(message_text):
    """Отправляет сообщение всем пользователям из базы данных"""
    
    # Загружаем список чатов
    try:
        with open(USERS_FILE, 'r', encoding='utf-8') as f:
            users_data = json.load(f)
            chat_ids = users_data.get('chat_ids', [])
    except Exception as e:
        print(f"❌ Ошибка при загрузке чатов: {e}")
        return
    
    if not chat_ids:
        print("⚠️ Список чатов пуст!")
        return
    
    print(f"📢 Начало рассылки сообщения: '{message_text}'")
    print(f"👥 Количество чатов: {len(chat_ids)}")
    print("-" * 60)
    
    # Создаем бота
    bot = Bot(token=BOT_TOKEN)
    
    success_count = 0
    error_count = 0
    
    # Отправляем сообщение в каждый чат
    for chat_id in chat_ids:
        try:
            await bot.send_message(
                chat_id=chat_id,
                text=message_text
            )
            success_count += 1
            print(f"✅ Отправлено в чат {chat_id}")
        except Exception as e:
            error_count += 1
            print(f"❌ Ошибка при отправке в чат {chat_id}: {e}")
    
    print("-" * 60)
    print(f"📊 Рассылка завершена!")
    print(f"   Успешно: {success_count}")
    print(f"   Ошибок: {error_count}")
    print(f"   Всего: {len(chat_ids)}")

if __name__ == "__main__":
    message = "Надо бы"
    asyncio.run(send_broadcast_message(message))
