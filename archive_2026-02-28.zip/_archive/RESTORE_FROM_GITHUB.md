# Восстановление проекта slashbot

**Проект восстановлен из локальной истории Cursor** (не из GitHub — репозитория на GitHub не было).

## Что было сделано

При вставке папки с заменой macOS заменил содержимое текущей папки тем, что было в буфере (у тебя там оказались только логи). Исходный код восстановлен из **Cursor Local History** (`~/Library/Application Support/Cursor/User/History/`).

Восстановлены файлы:
- `bot.py`, `config.py`, `web_app.py`
- `requirements.txt`, `.gitignore`, `Procfile`
- `README.md`, `WEB_INTERFACE_README.md`
- `start_bot.sh`, `start_web.sh`
- `send_message.py`, `send_broadcast.py`, `add_chat.py`
- `templates/index.html`
- `scheduled_messages.json` (пустой)

Логи `bot.error.log` и `bot.log` остались в папке.

## На будущее

1. **Инициализируй Git и привяжи к GitHub**, чтобы больше не терять код:
   ```bash
   cd "/Users/alexeygruzdev/Documents/Проекты/slashbot"
   git init
   git add .
   git commit -m "Restore project from Cursor history"
   # Создай репозиторий на github.com и:
   git remote add origin https://github.com/ТВОЙ_USERNAME/slashbot.git
   git push -u origin main
   ```

2. **Токен в config.py** — если будешь пушить в открытый репозиторий, вынеси токен в переменные окружения и добавь `config.py` в `.gitignore` или используй только `BOT_TOKEN` из `os.getenv`.
